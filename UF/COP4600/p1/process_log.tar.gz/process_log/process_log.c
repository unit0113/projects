#include "process_log.h"
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>


int get_proc_log_level() {
    return syscall(436);
}

int set_proc_log_level(int new_level) {
    return syscall(435, new_level);
}

int proc_log_message(int level, char *message) {
    return syscall(437, message, level);
}

// Harness functions
int* retrieve_set_level_params(int new_level) {
    int* ret_val = malloc(sizeof(int)*3);
    ret_val[0] = 435;
    ret_val[1] = 1;
    ret_val[2] = new_level;
    return ret_val;
}

int* retrieve_get_level_params() {
    int* ret_val = malloc(sizeof(int)*2);
    ret_val[0] = 436;
    ret_val[1] = 0;
    return ret_val;
}

int interpret_set_level_result(int ret_value) {
    return ret_value;
}

int interpret_get_level_result(int ret_value) {
    return ret_value;
}

int interpret_log_message_result(int ret_value) {
    return ret_value;
}
