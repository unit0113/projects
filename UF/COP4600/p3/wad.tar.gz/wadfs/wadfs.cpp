#include <iostream>
#include <string>
#include <filesystem>
#include <vector>

#include "../libWad/Wad.h"

#define FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

//https://www.cs.nmsu.edu/~pfeiffer/fuse-tutorial/html/private.html
#define WAD_DATA ((Wad*) fuse_get_context()->private_data)

//https://maastaar.net/fuse/linux/filesystem/c/2019/09/28/writing-less-simple-yet-stupid-filesystem-using-FUSE-in-C/
// Source applies for all callbacks (great source!)
static int getattr_callback(const char* path, struct stat* st) {
    // Fill in basic info
    st->st_uid = getuid();          // The owner of the file/directory is the user who mounted the filesystem
	st->st_gid = getgid();          // The group of the file/directory is the same as the group of the user who mounted the filesystem
	st->st_atime = time( NULL );    // The last "a"ccess of the file/directory is right now
	st->st_mtime = time( NULL );    // The last "m"odification of the file/directory is right now

    // Fill directory info
    if (WAD_DATA->isDirectory(std::string(path))) {
		st->st_mode = S_IFDIR | 0755;
		st->st_nlink = 2;
        return 0;
	}

    // Fill content info
    else if (WAD_DATA->isContent(std::string(path))) {
		st->st_mode = S_IFREG | 0644;
		st->st_nlink = 1;
		st->st_size = WAD_DATA->getSize(std::string(path));
        return 0;
	}
    
    // If doesn't exist
	return -ENOENT;
}

static int mknod_callback(const char* path, mode_t mode, dev_t rdev) {
    WAD_DATA->createFile(std::string(path));
    return 0;
}

static int mkdir_callback(const char* path, mode_t mode) {
    WAD_DATA->createDirectory(std::string(path));
    return 0;
}

static int read_callback(const char* path, char *buf, size_t size, off_t offset, struct fuse_file_info* fi) {
    if (WAD_DATA->isContent(std::string(path))) {
        return WAD_DATA->getContents(std::string(path), buf, size, offset);
    }
    return -ENOENT;
}

static int write_callback(const char* path, const char *buf, size_t size, off_t offset, struct fuse_file_info* fi) {
    int total, temp;
    temp = WAD_DATA->writeToFile(std::string(path), buf, size, offset);
    while (temp > 0) {
        total += temp;
        temp = WAD_DATA->writeToFile(std::string(path), buf + total, size - total, offset + total);
    }
    return total;
}

static int readdir_callback(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    filler( buffer, ".", NULL, 0 ); // Current Directory
	filler( buffer, "..", NULL, 0 ); // Parent Directory
    std::vector<std::string> directory;
    int dirSize = WAD_DATA->getDirectory(std::string(path), &directory);

    if (dirSize > 0) {
		for ( const std::string& item : directory)
			filler(buffer, item.data(), NULL, 0);
	}
    return 0;
}

static struct fuse_operations operations = {
  .getattr = getattr_callback,
  .mknod = mknod_callback,
  .mkdir = mkdir_callback,
  .read = read_callback,
  .write = write_callback,
  .readdir = readdir_callback,
};

// Stolen from project video because Ernesto (the best TA ever) said we could
int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Invalid Usage: not enough args" << std::endl;
        exit(EXIT_SUCCESS);
    }

    // Pull wad path from argv, account for flags
    std::string wadPath = argv[argc-2];

    //Account for relative pathing
    if (wadPath.at(0) != '/') {
        wadPath = std::string(get_current_dir_name() + '/' + wadPath);
    }

    Wad* myWad = Wad::loadWad(wadPath);

    // Ignore wad path when passing to fuse
    argv[argc - 2] = argv[argc - 1];
    --argc;

    return fuse_main(argc, argv, &operations, myWad);
}