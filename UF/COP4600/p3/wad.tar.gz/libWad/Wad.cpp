#include <regex>
#include <algorithm>

#include "Wad.h"

const std::regex mapMarkerRegex{"^E\\dM\\d$"};
const std::regex namespaceStartRegex{"^\\w\\w?_START$"};
const std::regex namespaceEndRegex{"^\\w\\w?_END$"};

TreeNode::TreeNode() {
    offset = 0;
    length = 0;
    fullName[0] = '/';
    fullName[1] = '\0';
    shortName = "/";
}

TreeNode::TreeNode(std::string name, bool isDirectory) {
    offset = 0;
    length = 0;
    std::fill(fullName, fullName+9, '\0');
    if (isDirectory){
        strcpy(fullName, (name + "_START").c_str());
    } else {
        strcpy(fullName, name.c_str());
    }    
    shortName = name;
}

TreeNode::TreeNode(std::fstream& file) {
    file.read((char*)&offset, 4);
    file.read((char*)&length, 4);
    fullName[8] = '\0';
    file.read(fullName, 8);
    shortName = std::string(fullName);
    if (isNamespaceMarkerStart()) {
        shortName = shortName.substr(0, shortName.find('_'));
    }
}

void TreeNode::addChild(TreeNode* node) {
    children.push_back(node);
}

void TreeNode::addChildren(std::fstream& file, std::string path, int& remainingDescriptors, std::unordered_map<std::string, TreeNode*>& items) {
    TreeNode* newNode;
    while (remainingDescriptors > 0) {
        // Read next descriptor
        newNode = new TreeNode(file);
        --remainingDescriptors;

        // Parse newNode
        // End loop if end of namespace directory, return to next level up
        if (newNode->isNamespaceMarkerEnd()) {
            delete newNode;
            break;
        } 
        
        TreeNode* newerNode;
        addChild(newNode);
        // Add if normal content
        if (newNode->isContent()) {
            items[path + newNode->getName()] = newNode;
        }
        // Parse map Marker directory in one block
        else if (newNode->isMapMarker()) {
            // Add directory to items and children
            items[path+newNode->getName() + "/"] = newNode;
            // Add 10 content files under newNode
            for (int i = 0; i < 10; ++i) {
                newerNode = new TreeNode(file);
                newNode->addChild(newerNode);
                items[path+newNode->getName() + "/" +newerNode->getName()] = newerNode;
            }
            remainingDescriptors -= 10;
        }
        // Recursive call if namespace directory
        else if (newNode->isNamespaceMarkerStart()) {
            // Add directory to items and children
            items[path+newNode->getName() + "/"] = newNode;
            // Read possible children
            newNode->addChildren(file, path + newNode->getName() + "/", remainingDescriptors, items);
        }
    }
}

void TreeNode::writeNode(std::fstream& file) {
    // Don't write root
    if (!isRoot()) {
        file.write((char*)&offset, sizeof(offset));
        file.write((char*)&length, sizeof(length));
        file.write(fullName, 8);
    }

    // Write children
    for (TreeNode* child : children) {
        child->writeNode(file);
    }

    // Write end if namespace
    if (isNamespaceMarkerStart()) {
        // Write dummy offset and length
        uint32_t dummyInt = 0;
        file.write((char*)&dummyInt, sizeof(dummyInt));
        file.write((char*)&dummyInt, sizeof(dummyInt));

        // Write name with END
        char temp[9];
        std::fill(temp, temp+9, '\0');
        std::strncpy(temp, shortName.data(), shortName.size());
        std::strncpy(temp + shortName.size(), "_END", 4);
        file.write(temp, 8);
    }
}

bool TreeNode::isMapMarker() const {
    return std::regex_match(fullName, mapMarkerRegex);
}

bool TreeNode::isNamespaceMarkerStart() const {
    return std::regex_match(fullName, namespaceStartRegex);
}

bool TreeNode::isNamespaceMarkerEnd() const {
    return std::regex_match(fullName, namespaceEndRegex);
}

bool TreeNode::isDirectory() const {
    return isMapMarker() || isNamespaceMarkerStart() || isRoot();
}

bool TreeNode::isContent() const {
    return !isDirectory();
}

bool TreeNode::isRoot() const {
    return shortName == "/";
}

bool TreeNode::canAddChildren() const {
    return isRoot() || isNamespaceMarkerStart();
}

bool TreeNode::isEmpty() const {
    return length == 0;
}

std::string TreeNode::getName() const {
    return shortName;
}

uint32_t TreeNode::getLength() const {
    return length;
}

uint32_t TreeNode::getOffset() const {
    return offset;
}

const std::vector<TreeNode*>& TreeNode::getChildren() const {
    return children;
}

void TreeNode::update(uint32_t newOffset, uint32_t newLength) {
    offset = newOffset;
    length = newLength;
}


Wad::~Wad() {
    for (auto& kv : items) {
        delete kv.second;
    }
    wadFile.close();
}

Wad* Wad::loadWad(const std::string &path) {
    return new Wad(path);
}
Wad::Wad(const std::string &path) {
    // Initilize stream to raw file
    wadFile.open(path, std::ios::in | std::ios::out | std::ios::binary);

    // Read header
    magic[4] = '\0';
    wadFile.read(magic, 4);
    wadFile.read((char*)&numDescriptors, 4);
    wadFile.read((char*)&descriptorOffset, 4);

    // Parse descriptors
    root = new TreeNode();
    items["/"] = root;
    wadFile.seekg(descriptorOffset, std::ios::beg);
    int descriptorsRemaining = numDescriptors;
    root->addChildren(wadFile, "/", descriptorsRemaining, items);
}

bool Wad::isContent(const std::string &path) {
    if (items.find(path) == items.end()) {return false;}
    return items[path]->isContent();
}

bool Wad::isDirectory(const std::string &path) {
    if (path.size() == 0) {return false;}
    std::string pathStr = getValidPath(path);

    if (items.find(pathStr) == items.end()) {return false;}
    return items[pathStr]->isDirectory();
}

int Wad::getSize(const std::string &path) {
    if (!isContent(path)) {return -1;}
    return (int)items[path]->getLength();
}

int Wad::getContents(const std::string &path, char *buffer, int length, int offset) {
    // Check if path is valid
    if (!isContent(path)) {return -1;}

    TreeNode* node = items[path];
    // Calc num bytes to copy
    int copyLength = std::min(length, (int)node->getLength() - offset);
    if (copyLength < 0) {return 0;}

    // Copy into buffer
    wadFile.seekg(node->getOffset() + offset, std::ios::beg);
    wadFile.read(buffer, copyLength);

    return copyLength;
}

int Wad::getDirectory(const std::string &path, std::vector<std::string> *directory) {
    // Check if path is valid
    if (!isDirectory(path)) {return -1;}
    std::string pathStr = getValidPath(path);

    // Add filenames to directory
    for (const TreeNode* node : items[pathStr]->getChildren()) {
        directory->push_back(node->getName());
    }
    return items[pathStr]->getChildren().size();
}

void Wad::createDirectory(const std::string &path) {
    // Validate input
    if (path == "/" || path.size() == 0 || isDirectory(path)) {return;}
    
    // Parse path
    std::string pathStr = path;
    if (pathStr.back() == '/') {pathStr.pop_back();}
    std::string parentPath = pathStr.substr(0, 1 + pathStr.rfind('/'));
    std::string dirName = pathStr.substr(1 + pathStr.rfind('/'));

    // Validate new directory name and parent directory
    if (dirName.size() > 2 || !isDirectory(parentPath) || !items[parentPath]->canAddChildren()) {return;}
    
    // Add
    TreeNode* newNode = new TreeNode(dirName);
    items[pathStr + "/"] = newNode;
    items[parentPath]->addChild(newNode);

    // Update header info and write changes
    numDescriptors += 2;
    writeHeader();
    writeDescriptors();
}

void Wad::createFile(const std::string &path) {
    // Validate input
    if (path == "/" || path.size() == 0 || isContent(path)) {return;}
    
    // Parse path
    std::string parentPath = path.substr(0, 1 + path.rfind('/'));
    std::string fileName = path.substr(1 + path.rfind('/'));
    
    // Validate new directory name and parent directory
    if (fileName.size() > 8 || !isDirectory(parentPath) || !items[parentPath]->canAddChildren() || std::regex_match(fileName.data(), mapMarkerRegex)) {return;}

    // Add
    TreeNode* newNode = new TreeNode(fileName, false);
    items[path] = newNode;
    items[parentPath]->addChild(newNode);

    // Update header info and write changes
    numDescriptors += 1;
    writeHeader();
    writeDescriptors();
}

int Wad::writeToFile(const std::string &path, const char *buffer, int length, int offset) {
    // Validate input
    if (!isContent(path)) {return -1;}
    if (!items[path]->isEmpty()) {return 0;}

    // Write to lump
    wadFile.seekg(descriptorOffset + offset, std::ios::beg);
    wadFile.write(buffer, length);

    // Update node
    items[path]->update(descriptorOffset, length);

    // Update header info and write changes
    descriptorOffset += length;
    writeHeader();
    writeDescriptors();
    return length;
}

std::string Wad::getValidPath(const std::string& path) {
    std::string pathStr = path;
    if (pathStr.back() != '/') {pathStr += '/';}
    return pathStr;
}

void Wad::writeHeader() {
    wadFile.seekg(0, std::ios::beg);
    wadFile.write(magic, 4);
    wadFile.write((char*)&numDescriptors, sizeof(numDescriptors));
    wadFile.write((char*)&descriptorOffset, sizeof(descriptorOffset));
}

void Wad::writeDescriptors() {
    wadFile.seekg(descriptorOffset, std::ios::beg);
    root->writeNode(wadFile);
}