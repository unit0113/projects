#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <fstream>


class TreeNode {
    private:
        uint32_t offset;
        uint32_t length;
        char fullName[9];
        std::string shortName;
        std::vector<TreeNode*> children;

    public:
        TreeNode();
        TreeNode(std::string name, bool isDirectory=true);
        TreeNode(std::fstream& file);
        void addChild(TreeNode* node);
        void addChildren(std::fstream& file, std::string path, int& remainingDescriptors, std::unordered_map<std::string, TreeNode*>& items);
        void writeNode(std::fstream& file);
        bool isMapMarker() const;
        bool isNamespaceMarkerStart() const;
        bool isNamespaceMarkerEnd() const;
        bool isDirectory() const;
        bool isContent() const;
        bool isRoot() const;
        bool canAddChildren() const;
        bool isEmpty() const;
        std::string getName() const;
        uint32_t getLength() const;
        uint32_t getOffset() const;
        const std::vector<TreeNode*>& getChildren() const;
        void update(uint32_t newOffset, uint32_t newLength);
};


class Wad {
    private:
        char magic[5];
        uint32_t numDescriptors, descriptorOffset;
        std::fstream wadFile;
        TreeNode* root;
        std::unordered_map<std::string, TreeNode*> items;

        Wad(const std::string &path);
        std::string getValidPath(const std::string& path);
        void writeHeader();
        void writeDescriptors();

    public:
        ~Wad();
        static Wad* loadWad(const std::string &path);
        std::string getMagic() {return magic;};
        bool isContent(const std::string &path);
        bool isDirectory(const std::string &path);
        int getSize(const std::string &path);
        int getContents(const std::string &path, char *buffer, int length, int offset = 0);
        int getDirectory(const std::string &path, std::vector<std::string> *directory);
        void createDirectory(const std::string &path);
        void createFile(const std::string &path);
        int writeToFile(const std::string &path, const char *buffer, int length, int offset = 0);

};