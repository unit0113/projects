//https://www.geeksforgeeks.org/socket-programming-cc/
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string>
#include <deque>
#include <limits>
#include <iostream>

#include "Messages.h"

const char NEWLINE[] = "\n";

void push(std::string msg, std::deque<std::string>& q, int maxSize) {
    q.push_back(msg);
    if (q.size() > maxSize) {q.pop_front();}
}

void clear(std::deque<std::string>& q, int client_fd) {
    q.clear();
    send(client_fd, &CLEAR_MESSAGE, strlen(CLEAR_MESSAGE), 0);
}

void tooBig(int client_fd, char lastRead) {
    send(client_fd, &ERROR_MESSAGE, strlen(ERROR_MESSAGE), 0);
    // Clear buffer
    int readSize;
    char buffer[1024];
    while(lastRead != '\n') {
        readSize = read(client_fd, &buffer, sizeof(buffer));
        lastRead = buffer[readSize-1];
    }
}

void post(std::deque<std::string>& q, int client_fd, int maxSize) {
    send(client_fd, &NAME_PROMPT, strlen(NAME_PROMPT), 0);
    
    // Get name
    char buffer[81];
    int readSize;
    std::fill_n(buffer, 81, '\0');
    readSize = read(client_fd, &buffer, 81);
    if (readSize > 78) {
        tooBig(client_fd, buffer[readSize-1]);
        return;
    }
    buffer[strlen(buffer)-1] = ':';
    buffer[strlen(buffer)] = ' ';

    std::string name = std::string(buffer);
    std::fill_n(buffer, 81, '\0');

    // Get msg
    send(client_fd, &POST_PROMPT1, strlen(POST_PROMPT1), 0);
    std::string len = std::to_string(80 - name.size());
    send(client_fd, len.data(), len.size(), 0);
    send(client_fd, &POST_PROMPT2, strlen(POST_PROMPT2), 0);
    readSize = read(client_fd, &buffer, 81);

    // Parse msg
    if (readSize > 81 - name.size()) {
        tooBig(client_fd, buffer[readSize-1]);
    } else {
        push(name + std::string(buffer), q, maxSize);
        send(client_fd, &SUCCESS_MESSAGE, strlen(SUCCESS_MESSAGE), 0);
    }
}

void kill(int client_fd, int server_fd) {
    send(client_fd, &KILL_MESSAGE, strlen(KILL_MESSAGE), 0);
    close(client_fd);
    close(server_fd);
}

void quit(int client_fd) {
    send(client_fd, &QUIT_MESSAGE, strlen(QUIT_MESSAGE), 0);
    close(client_fd);
}

int getClient(int server_fd, sockaddr_in address, socklen_t addrlen) {
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    int client_fd;
    if ((client_fd
         = accept(server_fd, (struct sockaddr*)&address,
                  &addrlen))
        < 0) {
        perror("accept");
        exit(EXIT_FAILURE);
    }
    return client_fd;
}

void printHeader(int client_fd, std::deque<std::string>& q, int queueSize) {
    send(client_fd, &WALL_HEADER, strlen(WALL_HEADER), 0);
    if (q.empty()) {
        send(client_fd, &EMPTY_MESSAGE, strlen(EMPTY_MESSAGE), 0);
    } else {
        for (const std::string& msg : q) {
            send(client_fd, msg.data(), msg.size(), 0);
        }
    }
    send(client_fd, &NEWLINE, strlen(NEWLINE), 0);
    send(client_fd, &COMMAND_PROMPT, strlen(COMMAND_PROMPT), 0);
}

int main(int argc, char const* argv[]) {
    int server_fd, client_fd;
    struct sockaddr_in address;
    int opt = 1;
    socklen_t addrlen = sizeof(address);
    char buffer[81];
    int queueSize = argc > 1 ? std::stoi(argv[1]) : 20;
    int port = argc > 2 ? std::stoi(argv[2]) : 5514;
    std::deque<std::string> msgQ;
 
    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
 
    // Forcefully attaching socket to the port
    if (setsockopt(server_fd, SOL_SOCKET,
                   SO_REUSEADDR | SO_REUSEPORT, &opt,
                   sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);
 
    // Forcefully attaching socket to the port
    if (bind(server_fd, (struct sockaddr*)&address,
             sizeof(address))
        < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    client_fd = getClient(server_fd, address, addrlen);

    // Main loop
    std::string cmd;
    while (true) {
        std::fill_n(buffer, 81, '\0');
        printHeader(client_fd, msgQ, queueSize);
        read(client_fd, &buffer, 81);
        cmd = std::string(buffer);

        // Parse cmds
        if (cmd == "clear\n") {
            clear(msgQ, client_fd);
        } else if (cmd == "kill\n") {
            msgQ.clear();
            kill(client_fd, server_fd);
            return 0;
        } else if (cmd == "quit\n") {
            quit(client_fd);
            client_fd = getClient(server_fd, address, addrlen);
        } else if (cmd == "post\n") {
            post(msgQ, client_fd, queueSize);
        }
    }
    return 0;
}